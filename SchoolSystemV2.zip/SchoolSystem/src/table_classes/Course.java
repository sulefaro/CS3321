/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package table_classes;

/**
 *
 * @author Joiney
 */
public class Course {
    
    private int courseID;
    private String subject;
    private int courseNumber;
    private String courseName;
    private String semester;
    private int year;
    private String professor;
    private int room;
    private String building;
    private String days;
    private String time;
    private int quiz1;
    private int quiz2;
    private int quiz3;
    private int midterm;
    private int finalExam;
    
         
   
    
    
    
    public Course(String subject, int courseNumber, String courseName, 
            String semester, int year, String professor, int room, String building, String days,
            String time)
            
    {
        this.subject = subject;
        this.courseNumber = courseNumber;
        this.courseName = courseName;
        this.semester = semester;
        this.year = year;
        this.professor = professor;
        this.room = room;
        this.building = building;
        this.days = days;
        this.time = time;   
    }

       public Course(String subject, int courseNumber, String courseName,
             int quiz1, int quiz2, int quiz3, int midterm, int finalExam)
             
    {
        
        this.subject = subject;
        this.courseNumber = courseNumber;
        this.courseName = courseName;
        this.quiz1 = quiz1;
        this.quiz2 = quiz2;
        this.quiz3 = quiz3;
        this.midterm = midterm;
        this.finalExam = finalExam;
    
    }
     
    
    
    
    public int getCourseID()
    {
        return courseID;
    }
    public String getSubject()
    {
        return subject;
    }
    public int getCourseNumber()
    {
        return courseNumber;
    }
    public String getCourseName()
    {
        return courseName;
    }
    public String getSemester()
    {
        return semester;
    }
    public int getYear()
    {
        return year;
    }
    public String getProfessor()
    {
        return professor;
    }
    public int getRoom()
    {
        return room;
    }
    public String getBuilding()
    {
        return building;
    }
    public String getDays()
    {
        return days;
    }
    public String getTime()
    {
        return time;
    }
    public int getQuiz1()
    {
        return quiz1;
    }
    public int getQuiz2()
    {
        return quiz2;
    }
    public int getQuiz3()
    {
        return quiz3;
    }
    public int getMidterm()
    {
        return midterm;
    }
    public int getFinalExam()
    {
        return finalExam;
    }
   

  
   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package misc;
import java.util.Random;


/**
 *
 * @author Joiney
 */
public class usernameGenerator {
    
    public String generateUsername(String firstName, String lastName){
        
        Random rand = new Random();
        int n = rand.nextInt(999);

        String usernameGenerated = firstName.substring(0,1) + lastName + n;
        
        return usernameGenerated;
        
    }
    
    
    
}

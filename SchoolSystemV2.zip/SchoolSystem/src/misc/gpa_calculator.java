/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package misc;

import java.util.ArrayList;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.List;

/**
 *
 * @author Joiney
 */
public class gpa_calculator {
    
    
    static DecimalFormat dc = new DecimalFormat("0.00");
    static ArrayList<Integer> credit_hour_array = new ArrayList<Integer>();
    static ArrayList<Integer> grade_array = new ArrayList<Integer>();
    static ArrayList<Integer> grade_points_array = new ArrayList<Integer>();
    static int creditHours;
    static int gradePoints;
    static String courseNumber_STRING;
    static float course_grade_float;
    
    
     static public float get_course_grade(int quiz1, int quiz2, int quiz3, int midterm, int finalExam)
    {
        float quiz_pts = (float) (((quiz1 + quiz2 + quiz3)/3)*0.3);
        float midterm_pts = (float)(midterm * 0.3);
        float finalExam_pts = (float) (finalExam * 0.4);
        
        course_grade_float = quiz_pts + midterm_pts + finalExam_pts;
        
        return course_grade_float;
    }
    
  
    static public void get_credit_hours(int courseNumber)
    {
        courseNumber_STRING = Integer.toString(courseNumber);
        creditHours = Character.getNumericValue(courseNumber_STRING.charAt(0));
        
        credit_hour_array.add(creditHours);
    }
    
    static public void get_grade_points(float courseGrade)
    {
        
        
        if(courseGrade <= 100 && courseGrade >= 90)
        {
            gradePoints = 4;
        }
        else if(courseGrade <= 89 && courseGrade >= 80)
        {
            gradePoints = 3;
        }
        else if(courseGrade <= 79 && courseGrade >= 70)
        {
            gradePoints = 2;
        }
        else if(courseGrade <= 69 && courseGrade >= 60)
        {
            gradePoints = 1;
        }
        else if(courseGrade <= 59 && courseGrade >= 50)
        {
            gradePoints = 0;
        }
        else
        {
            gradePoints = 0;
        }
        
        grade_array.add(gradePoints);
        
    }
    
   
    static public float calculate_gpa(int list_size)
    {
        int total_credit_hours = 0;
        int total_grade_points = 0;
        float gpa;
        
        //product of credit hours and grade (3 * A)
        for(int i = 0; i < list_size; i++)
        {
            grade_points_array.add(credit_hour_array.get(i) * grade_array.get(i));
        }
        //total number of credit hours 
        for(int i = 0; i < list_size; i++)
        {
            total_credit_hours = total_credit_hours + credit_hour_array.get(i);
        }
        //total grade points
        for(int i = 0; i < list_size; i++)
        {
            total_grade_points = total_grade_points + grade_points_array.get(i);
        }
        //gpa is total grade points / total credit hours
        
        
        grade_points_array.clear();
        grade_array.clear();
        credit_hour_array.clear();
                
        gpa = ((float)total_grade_points)/((float)total_credit_hours);
        
        
        
        return gpa;
    }
    
    
}

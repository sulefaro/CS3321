/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQL;
import java.sql.*;
import javax.swing.*;

/**
 *
 * @author Joiney
 */
public class MySQL {
    Connection conn = null;
    public static Connection ConnectDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/schoolsystem","root","Password123");
            
            return conn;
        }
    catch(Exception e){
    JOptionPane.showMessageDialog(null,e);
    return null;
    }
    }

    
   
    
    //Display data in Jtable
   
}
    


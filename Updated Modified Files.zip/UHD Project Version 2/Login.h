#pragma once

#include <string>
#include <iostream>
#include <fstream>
#include <msclr\marshal_cppstd.h>
#include "studentForm.h"



namespace UHDProjectVersion2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	//using namespace System::String;
	using namespace std;

	public ref class Login : public System::Windows::Forms::Form
	{
	public:
		int loginDB(string username, string password);
		Login(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Login()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	protected:
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::TextBox^ passBox;
	private: System::Windows::Forms::TextBox^ userBox;
	private: System::Windows::Forms::PictureBox^ pictureBox3;
	private: System::Windows::Forms::PictureBox^ loginButton;
	private: System::Windows::Forms::Button^ forgotPass;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Login::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->passBox = (gcnew System::Windows::Forms::TextBox());
			this->userBox = (gcnew System::Windows::Forms::TextBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->loginButton = (gcnew System::Windows::Forms::PictureBox());
			this->forgotPass = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->loginButton))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Location = System::Drawing::Point(322, 16);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(164, 70);
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.BackgroundImage")));
			this->pictureBox2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox2->Location = System::Drawing::Point(271, 162);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(32, 30);
			this->pictureBox2->TabIndex = 1;
			this->pictureBox2->TabStop = false;
			// 
			// passBox
			// 
			this->passBox->BackColor = System::Drawing::Color::MidnightBlue;
			this->passBox->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->passBox->Font = (gcnew System::Drawing::Font(L"Adobe Heiti Std R", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->passBox->ForeColor = System::Drawing::SystemColors::Window;
			this->passBox->Location = System::Drawing::Point(322, 209);
			this->passBox->Name = L"passBox";
			this->passBox->PasswordChar = '*';
			this->passBox->Size = System::Drawing::Size(206, 30);
			this->passBox->TabIndex = 4;
			// 
			// userBox
			// 
			this->userBox->BackColor = System::Drawing::Color::MidnightBlue;
			this->userBox->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->userBox->Font = (gcnew System::Drawing::Font(L"Adobe Heiti Std R", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->userBox->ForeColor = System::Drawing::Color::LightGoldenrodYellow;
			this->userBox->Location = System::Drawing::Point(322, 162);
			this->userBox->Name = L"userBox";
			this->userBox->Size = System::Drawing::Size(206, 30);
			this->userBox->TabIndex = 5;
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox3->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox3.BackgroundImage")));
			this->pictureBox3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox3->Location = System::Drawing::Point(271, 209);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(32, 30);
			this->pictureBox3->TabIndex = 6;
			this->pictureBox3->TabStop = false;
			// 
			// loginButton
			// 
			this->loginButton->BackColor = System::Drawing::Color::Transparent;
			this->loginButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"loginButton.BackgroundImage")));
			this->loginButton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->loginButton->Location = System::Drawing::Point(382, 245);
			this->loginButton->Name = L"loginButton";
			this->loginButton->Size = System::Drawing::Size(68, 44);
			this->loginButton->TabIndex = 7;
			this->loginButton->TabStop = false;
			this->loginButton->Click += gcnew System::EventHandler(this, &Login::LoginButton_Click);
			// 
			// forgotPass
			// 
			this->forgotPass->Location = System::Drawing::Point(47, 332);
			this->forgotPass->Name = L"forgotPass";
			this->forgotPass->Size = System::Drawing::Size(75, 23);
			this->forgotPass->TabIndex = 8;
			this->forgotPass->UseVisualStyleBackColor = true;
			// 
			// Login
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSteelBlue;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(809, 393);
			this->Controls->Add(this->forgotPass);
			this->Controls->Add(this->loginButton);
			this->Controls->Add(this->pictureBox3);
			this->Controls->Add(this->userBox);
			this->Controls->Add(this->passBox);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->DoubleBuffered = true;
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Login";
			this->Text = L"Login";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->loginButton))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		//Login Button Function
	private: System::Void LoginButton_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ cUserName = userBox->Text;
		String^ cPassName = passBox->Text;

		std::string userName = msclr::interop::marshal_as<std::string>(cUserName);
		std::string password = msclr::interop::marshal_as<std::string>(cPassName);
		

		int checkLogin = loginDB(userName, password);

		if (checkLogin == 0) //Student Screen
		{
			MessageBox::Show("Login Successful! Welcome Student", "Info", MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
			this->Hide();
			studentForm^ student = gcnew studentForm();
			student->Show();
		}
		else if (checkLogin == 1) // Admin Screen
			MessageBox::Show("Login Successful! ADMIN, please try again.", "Info", MessageBoxButtons::OK, MessageBoxIcon::Exclamation);

		else if (checkLogin == 2);
		//MessageBox::Show("Incorrect Login, please try again.", "Info", MessageBoxButtons::OK, MessageBoxIcon::Exclamation);

		}
			
	};
};

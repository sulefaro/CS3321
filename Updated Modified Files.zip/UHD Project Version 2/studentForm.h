#pragma once

namespace UHDProjectVersion2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for studentForm
	/// </summary>
	public ref class studentForm : public System::Windows::Forms::Form
	{
	public:
		studentForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~studentForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^ studentTable;
	protected:





	private: System::Windows::Forms::Label^ studentID;

	private: System::Windows::Forms::Label^ flName;
	private: System::Windows::Forms::Label^ GPAvalue;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Year;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ classSemester;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ courseName;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ subject;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ grade;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(studentForm::typeid));
			this->studentTable = (gcnew System::Windows::Forms::DataGridView());
			this->studentID = (gcnew System::Windows::Forms::Label());
			this->flName = (gcnew System::Windows::Forms::Label());
			this->GPAvalue = (gcnew System::Windows::Forms::Label());
			this->Year = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->classSemester = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->courseName = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->subject = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grade = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->studentTable))->BeginInit();
			this->SuspendLayout();
			// 
			// studentTable
			// 
			this->studentTable->AllowUserToOrderColumns = true;
			this->studentTable->BackgroundColor = System::Drawing::SystemColors::GradientActiveCaption;
			this->studentTable->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->studentTable->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->studentTable->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(5) {
				this->Year, this->classSemester,
					this->courseName, this->subject, this->grade
			});
			this->studentTable->EnableHeadersVisualStyles = false;
			this->studentTable->Location = System::Drawing::Point(26, 27);
			this->studentTable->Name = L"studentTable";
			this->studentTable->Size = System::Drawing::Size(541, 297);
			this->studentTable->TabIndex = 0;
			this->studentTable->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &studentForm::DataGridView1_CellContentClick);
			// 
			// studentID
			// 
			this->studentID->AutoSize = true;
			this->studentID->BackColor = System::Drawing::Color::Transparent;
			this->studentID->Font = (gcnew System::Drawing::Font(L"Franklin Gothic Book", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->studentID->Location = System::Drawing::Point(25, 334);
			this->studentID->Name = L"studentID";
			this->studentID->Size = System::Drawing::Size(82, 20);
			this->studentID->TabIndex = 1;
			this->studentID->Text = L"Student ID:";
			// 
			// flName
			// 
			this->flName->AutoSize = true;
			this->flName->BackColor = System::Drawing::Color::Transparent;
			this->flName->Font = (gcnew System::Drawing::Font(L"Franklin Gothic Book", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->flName->Location = System::Drawing::Point(192, 336);
			this->flName->Name = L"flName";
			this->flName->Size = System::Drawing::Size(152, 20);
			this->flName->TabIndex = 2;
			this->flName->Text = L"First Name Last Name";
			// 
			// GPAvalue
			// 
			this->GPAvalue->AutoSize = true;
			this->GPAvalue->BackColor = System::Drawing::Color::Transparent;
			this->GPAvalue->Font = (gcnew System::Drawing::Font(L"Franklin Gothic Book", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->GPAvalue->Location = System::Drawing::Point(411, 336);
			this->GPAvalue->Name = L"GPAvalue";
			this->GPAvalue->Size = System::Drawing::Size(39, 20);
			this->GPAvalue->TabIndex = 3;
			this->GPAvalue->Text = L"GPA:";
			// 
			// Year
			// 
			this->Year->HeaderText = L"Year";
			this->Year->Name = L"Year";
			// 
			// classSemester
			// 
			this->classSemester->HeaderText = L"Semester";
			this->classSemester->Name = L"classSemester";
			// 
			// courseName
			// 
			this->courseName->HeaderText = L"Course";
			this->courseName->Name = L"courseName";
			// 
			// subject
			// 
			this->subject->HeaderText = L"Subject";
			this->subject->Name = L"subject";
			// 
			// grade
			// 
			this->grade->HeaderText = L"Grade";
			this->grade->Name = L"grade";
			// 
			// studentForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuText;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(593, 365);
			this->Controls->Add(this->GPAvalue);
			this->Controls->Add(this->flName);
			this->Controls->Add(this->studentID);
			this->Controls->Add(this->studentTable);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"studentForm";
			this->Text = L"`";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->studentTable))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

			//Initializer


			//While loop


			//this.studentTable.Rows.Add("2019","CS","","Software Engineering","B");
			//this.studentTable.Rows.Add("2019", "CS", "", "Software Engineering", "C");

			//studentTable.Items.Add("A");
			//studentTable.Items.Add("B");
			//studentTable.Items.Add("C);
			//this->studentTable.Rows.Insert(0, "one", "two", "three", "four");

		}
#pragma endregion
	private: System::Void DataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
	}
};
}

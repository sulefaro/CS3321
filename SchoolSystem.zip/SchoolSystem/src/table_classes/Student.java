/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package table_classes;

/**
 *
 * @author Joiney
 */
public class Student {
    
    private int studentID;
    private String username;
    private String password;
    private String fName;
    private String lName;
    private String dob;
    private String classYear;
    private String major;
    private String address;
    private String city;
    private String state;
    private String zip;
    private String phone;
    private String email;
    
    
    public Student(int studentID, String username, 
            String fName, String lName, String dob, String classYear, 
            String major, String address, String city, String state, String zip,
            String phone, String email)
    {
        this.studentID = studentID;
        this.username = username;
        this.password = password;
        this.fName = fName;
        this.lName = lName;
        this.dob = dob;
        this.classYear = classYear;
        this.major = major;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.phone = phone;
        this.email = email;
    }
    
    public int getStudentID()
    {
        return studentID;
    }
    public String getUsername()
    {
        return username;
    }
    public String getPassword()
    {
        return password;
    }
    public String getFName()
    {
        return fName;
    }
    public String getLName()
    {
        return lName;
    }
    public String getDob()
    {
        return dob;
    }
    public String getClassYear()
    {
        return classYear;
    }
    public String getMajor()
    {
        return major;
    }
    public String getAddress()
    {
        return address;
    }
    public String getCity()
    {
        return city;
    }
    public String getState()
    {
        return state;
    }
    public String getZip()
    {
        return zip;
    }
    public String getPhone()
    {
        return phone;
    }
    public String getEmail()
    {
        return email;
    }

}

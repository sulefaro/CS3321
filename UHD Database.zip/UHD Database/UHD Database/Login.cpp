#include "Login.h"
using namespace System;
[STAThreadAttribute]

int main()
{
	System::Windows::Forms::Application::Run(gcnew UHDDatabase::Login());
	System::Windows::Forms::Application::EnableVisualStyles();
	return 0;
}

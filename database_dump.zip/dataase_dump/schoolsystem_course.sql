-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: schoolsystem
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `course` (
  `courseID` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(45) NOT NULL,
  `courseNumber` int(11) NOT NULL,
  `courseName` varchar(100) NOT NULL,
  `semester` varchar(45) NOT NULL,
  `year` int(11) NOT NULL,
  `professor` varchar(45) NOT NULL,
  `room` int(11) NOT NULL,
  `building` varchar(45) NOT NULL,
  `days` varchar(45) NOT NULL,
  `time` varchar(45) NOT NULL,
  PRIMARY KEY (`courseID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'ENG',3311,'Studies in Poetry','Fall',2019,'Burnett',210,'Arnold','MW','8:00-9:30'),(2,'ENG',3312,'Studies in Fiction','Fall',2019,'Mosby',212,'Arnold','MW','10:00AM-11:30AM'),(3,'ENG',3313,'Studies in Dramatic Literature','Fall',2019,'Mosby',212,'Arnold','TTH','5:00PM-6:30PM'),(4,'ENG',3307,'Shakespeare','Fall',2019,'Jackson',208,'Arnold','MW','10:00AM-11:30AM'),(5,'ENG',3322,'Mexican-American Literature','Fall',2019,'Shelby',215,'Arnold','F','9:00AM-11:00AM'),(6,'ETC',3301,'Educational Technology','Fall',2019,'Carrie',302,'Macon','TTH','3:00PM-4:30PM'),(7,'ESL',3303,'English Language Learners','Fall',2019,'Wilson',322,'Macon','S','1:00PM-3:00PM'),(8,'MATH',3321,'Math Concepts I','Fall',2019,'Barney',314,'Macon','W','7:00PM-9:00PM'),(9,'MATH',3322,'Math Concepts II','Fall',2019,'Barney',314,'Macon','M','8:00AM-10:00AM'),(10,'NS',3311,'Earth and Environmental Science Studies','Fall',2019,'Olsen',316,'Macon','F','12:00PM-2:00PM'),(11,'CS',3321,'Software Engineering','Fall',2019,'Frank',404,'Tiller','MW','9:00AM-10:30AM'),(12,'CS',4315,'Operating System','Fall',2019,'Zhang',408,'Tiller','MW','9:00AM-10:30AM'),(13,'CS',4318,'Database System','Fall',2019,'Morris',409,'Tiller','T','6:00AM-7:30AM'),(14,'CS',3304,'Data and Information Structure','Fall',2019,'Hao',410,'Tiller','TTH','4:00PM-5:30PM'),(15,'CS',3306,'Intro to Theory of Computation','Fall',2019,'Amari',404,'Tiller','F','2:00PM-4:00PM'),(16,'MBA',6310,'Advanced Taxation','Fall',2019,'Caldwell',355,'Hubbard','TTH','4:00PM-5:30PM'),(17,'MBA',6314,'Accounting Research & Writing','Fall',2019,'Porter',352,'Hubbard','S','6:00PM-8:00PM'),(18,'MBA',6312,'Advanced Auditing','Fall',2019,'Lawson',366,'Hubbard','MW','1:00PM-2:30PM'),(19,'MBA',6315,'Advanced Accounting Topics','Fall',2019,'Morgan',371,'Hubbard','W','10:00AM-12:00AM'),(20,'MBA',6102,'Industry Specific Topics in Accounting','Fall',2019,'Paige',349,'Hubbard','Th','8:00AM-10:00AM'),(21,'MATH',2401,'Calculus I','Spring',2019,'Barney',150,'Macon','TTH','12:00PM-1:30PM'),(22,'MATH',2402,'Calculus II','Summer',2019,'Barney',152,'Macon','MW','2:00PM-3:30PM');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 23:41:43
